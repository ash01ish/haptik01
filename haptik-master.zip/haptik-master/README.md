# haptik

Please extract the zip for Q1 and Q2. 
